# Paste this to your office Claude (Claude Code), after copying this folder into the repo at `docs/redesign/`

---

I want to redesign the UI of this app (IB Architecture: Profile Builder, Portfolio Grid, Editor, App Detail) and add two new features (a ⌘K command palette and a Compare & Rationalise page).

The full spec is in `docs/redesign/`:
- `HANDOFF.md` — the brief: design system, per-screen specs, data needs, build order. Read all of it first.
- `tokens.css` — design tokens.
- `designs/*.dc.html` — design source for each screen. They won't render in a browser; read them as specs. Inline styles hold exact values, and the `Component` class at the bottom shows behaviour.
- `screenshots/` — how each screen should look (if present).

Before writing any code:
1. Explore the repo: frontend framework, routing, styling approach, component library, how data is fetched, and the backend endpoints these pages use.
2. Write `docs/redesign/PLAN.md` that maps each design element to existing files and components (reuse vs new), and lists:
   - every place the design needs data we don't have yet (marked NEEDS DATA in the brief);
   - any dependencies you'd like to add.
3. Stop and show me the plan.

Then build in the phases in HANDOFF.md §8, one phase at a time, stopping for my review after each. Rules: don't change APIs or the data model without asking, never invent data (bracketed text in the designs means "wire to a real field or hide"), keep existing save/download behaviour, and make everything keyboard-accessible.
