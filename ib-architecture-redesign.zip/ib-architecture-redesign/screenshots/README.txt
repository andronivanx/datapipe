Export each artboard from the design canvas (Share › Export as PNG/PDF) and drop the images here.
