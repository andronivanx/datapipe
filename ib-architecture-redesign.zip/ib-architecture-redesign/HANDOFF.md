# IB Architecture — UI Redesign Handoff

This is the implementation brief for redesigning the **IB Architecture** prototype (the React app on `localhost:3000`). It covers six screens: four redesigns of existing pages and two new features.

Read this whole file first, then open the matching file in `designs/` for each screen you build.

---

## 1. Goal and ground rules

**Goal.** Make the existing tool feel production-grade: clear hierarchy, consistent components, faster decisions. Keep the same data, routes and core workflows.

**Ground rules**
1. **Do not change the data model or APIs without asking.** Most of this is a front-end change. Where a feature needs new data (marked **NEEDS DATA** below), propose the API change before building it.
2. **Never invent data.** Text in `[square brackets]` in the designs is a placeholder for a real field. Wire it to real data, or hide the row if the field doesn't exist.
3. **Reuse before you create.** Look at the existing components and styling approach in the repo first. Map each design element to an existing component where possible.
4. **Ask before adding dependencies.** Suggested libraries are listed in §7, but check what the repo already uses.
5. **Build in phases (§8)** and stop for review after each phase.

---

## 2. How to read the design files

`designs/*.dc.html` are design-canvas source files. They will **not** render if you open them directly, because they need the canvas runtime. Read them as specs:

| In the file | What it tells you |
|---|---|
| Inline `style="…"` | Exact spacing, sizes, colours, radii. These are the source of truth for visual values. |
| `{{name}}` | A value computed in the `Component` class at the bottom of the file. |
| `<sc-for list="{{items}}" as="x">` | A loop: render once per item. |
| `<sc-if value="{{cond}}">` | Conditional rendering. |
| `onClick="{{fn}}"` etc. | The interaction. Look up `fn` in `renderVals()` to see the behaviour. |
| `class Component … renderVals()` | Behaviour, derived state and **sample data**. Port the logic, not the hard-coded arrays. |
| `href="PortfolioGrid.dc.html"` | Navigation to another screen (see route map in §4). |

Screenshots of each screen are in `screenshots/` if they were exported. Use them for the overall look; use the source for exact values.

---

## 3. Design system

Implement these as shared tokens. `tokens.css` contains them as CSS custom properties. If the repo uses Tailwind or a theme object, port them there instead.

### Typography
- **IBM Plex Sans** (400/500/600/700) for UI text; **IBM Plex Mono** (400/500) for IDs, ports, counts and keyboard hints.
- Page title 30px/700, letter-spacing -0.01em. Section title 17px/600. Body 14–15px. Labels 12–13px/600. Overline 11–12px/600–700, uppercase, letter-spacing 0.06em.
- Any APM ID, service ID, port or count uses the mono font.

### Colour
| Token | Hex | Use |
|---|---|---|
| ink | `#0F1729` | Primary text |
| ink-2 | `#3A4458` | Secondary text |
| muted | `#5A6478` | Hints, labels (meets 4.5:1 on white) |
| ground | `#F3F4F7` | Page background |
| surface | `#FFFFFF` | Cards |
| line | `#E3E6EE` | Card borders |
| line-soft | `#EEF0F5` | Dividers inside cards |
| nav | `#0B1222` | Top bar, dark panels, stage badges |
| nav-2 | `#1A2338` / `#26324F` | Inputs and active items on dark |
| accent | `#3550E0` | Primary buttons, links, selection |
| accent-soft | `#EEF1FD` | Selected rows and chips |

**House position (strategic state)** is the core colour language. Use these everywhere: grid chips, badges, legends.

| State | Solid | Soft bg | Text on soft |
|---|---|---|---|
| Invest | `#1B7F4B` | `#E6F4EC` | `#17663D` |
| Maintain | `#3550E0` | `#EEF1FD` | `#2236A8` |
| Divest | `#C2570C` | `#FCEBDD` | `#9A3F05` |
| Cease | `#C0352B` | `#FDECEA` | `#A12A21` |
| Unknown | `#6B7385` | `#F1F2F5` | `#4A5468` |

**Status / attention:** warning `#C77700` (soft `#FDF1DC`, text `#8A5100`); success = Invest green; error = Cease red.

**Capability group tags** (soft bg / text): Onboarding & Enablement `#E8F5F6/#0B6168`; Relationship & CRM `#EEF1FD/#2236A8`; Marketing & Campaigns `#FCEFF5/#9C2A5E`; Ideation & Authoring `#EFEBFB/#4B2FAE`; Compliance & Workflow `#FCF3E6/#8A5100`.

**Stage badges:** numbered stages (1–6, "sequential") get a dark badge `#0B1222` with white mono text. Lettered stages (A–D, "cross-cutting") get a purple badge `#EFEBFB/#4B2FAE`. Type pills: sequential `#EEF1FD/#2236A8`, cross-cutting `#FCF3E6/#8A5100`.

### Shape and spacing
- Radii: cards 16px, inner cards/tiles 12–14px, inputs/buttons 10px, chips 6–8px, pills 999px.
- Card: white, 1px `line` border, no shadow. Shadows only on overlays (palette `0 24px 64px rgba(11,18,34,.35)`) and floating bars.
- Page container: max-width 1376–1440px, padding 28px 32px. Gaps between cards: 20–24px.
- Inputs and buttons: 40px tall (44px for primary actions). Touch targets at least 44px where possible.

### Shared components to build once
`AppShell` (dark top bar + nav + ⌘K search trigger), `Card`, `SectionHeader`, `Button` (primary / secondary / ghost / danger-text), `SegmentedControl`, `ToggleChip` (aria-pressed), `StatePill` (house position), `GroupTag`, `StageBadge`, `Avatar` (initials), `KpiTile`, `Checkbox`, `SearchInput`, `EmptyState`, `InspectorPanel`, `StickyActionBar`, `Toast`.

---

## 4. Routes

| Screen | Design file | Route (existing app) |
|---|---|---|
| App Profile Builder | `ProfileBuilder.dc.html` | `/` |
| Portfolio Grid | `PortfolioGrid.dc.html` | `/grid` |
| Capability & Area Editor | `Editor.dc.html` | `/editor` |
| App Detail | `AppDetail.dc.html` | `/app/:name` (e.g. `/app/FX%20One`) |
| Command Palette (new) | `CommandPalette.dc.html` | Global overlay, opened with ⌘K / Ctrl+K from any route |
| Compare & Rationalise (new) | `Compare.dc.html` | New route, e.g. `/compare?capability=…&area=…` |

---

## 5. Screen specs

### 5.1 App Profile Builder (`ProfileBuilder.dc.html`)
Purpose: select apps, set default business segments, tick the capabilities they provide, then save or download profiles.

- **Find applications card.** Filters: Application owner, System architect, "App name contains", Apply filter, Clear. "Select all visible" / "Clear selection". Count "N of 1,228 apps selected". Each row: checkbox, name, transaction-cycle tag (colour by cycle), "✓ Saved" indicator. Selected rows get the accent-soft background.
- **Business segments card.** All areas as toggle chips. Parent areas and their children are grouped in one bordered cluster: Liquid Finance → Fixed Income Finance, Prime, Securitized Products; Macro → Credit, FX, Rates; Resource Management Group → Collateral Optimization Unit. Parent chips are bold with a stronger border. Default From/To dates below.
- **Capabilities provided.** Search box. Accordion of the 10 stages (1–6, A–D), each with stage badge, name, "N selected" pill when relevant, "N capabilities" count, Select all, Clear. Inside: domain headings, then capability cards in a 2-column grid (name, group tag, description, checkbox).
- **When a capability is ticked:** the card expands to full width and shows the per-capability override:
  - Areas chips, showing "Inherits defaults · N" (green) until any chip is changed, then "Custom · N selected" (amber) with "Reset to defaults".
  - From / To dates.
- **Selected capabilities bar** (sticky to the bottom of the viewport). Removable chips per selected capability (stage id + name). Buttons: Clear selection, Download all JSON, Save all profiles. The last two are disabled until at least 1 app **and** 1 capability are selected.
- Keep the existing save and JSON download behaviour and payload shape.

### 5.2 Portfolio Grid (`PortfolioGrid.dc.html`)
Purpose: show which apps provide each capability per area, and surface gaps, overlaps and risk.

- **Quick-view cards (4).** Clicking one switches the grid's "lens"; clicking it again returns to All. The active card is filled with its colour and shows "Viewing". A banner explains the lens and has "Show everything".
  - *Applications mapped*: count of apps, plus "X of Y capabilities covered".
  - *Coverage gaps*: capabilities with **no** app in the visible areas. The lens shows only those rows.
  - *Overlap hotspots*: cells with **≥ 4** apps (make the threshold a constant). The lens shows only rows containing a hotspot, dims other cells, and outlines hotspot cells in amber.
  - *Divest & cease*: apps whose state is Divest or Cease. The lens shows only those chips and their rows.
- **Filters.** Focus on ITBA (app select, label `Name (APM ID)`), Application owner, "Find an application" (highlights matches and dims the rest, without filtering), timeline range slider ("No date" to a date), "Include no-date apps".
- **House position legend** doubles as a filter: toggle chips with counts. An off state is dashed and struck through.
- **View switch:** Applications (chips) / Heatmap. In heatmap, each cell shows the app count, a shade from accent-soft to accent by count, and a thin stacked bar of the state mix. Clicking a cell switches to Applications view with that cell expanded.
- **Density switch:** Comfortable / Compact.
- **Columns · Rows button** opens the show/hide panel: area toggle chips with Show all and Hide empty; domain toggle chips with Show all and Hide empty rows.
- **Grid table.**
  - Header row 1: area groups (Liquid Finance, Macro, Resource Management Group) spanning their child columns. Areas without a parent span both header rows.
  - Header row 3: app-link total per column, with a mini bar.
  - The header row and the first (capability) column stay fixed while scrolling.
  - Domain rows are collapsible bars: stage badge, name, "N of M shown · K app links".
  - Each capability row shows its total, or an amber "Gap" tag if it has none.
  - Cells show up to 4 chips, then "+N more" (expand / "Show less").
  - Chips: soft state background, state dot, truncated name with the full name in a tooltip.
  - Clicking a chip selects that app across the whole grid. A dark bar shows "Name · State · in N cells" with "Open app detail →".
- **Performance:** 1,228 apps × ~136 capabilities × ~25 areas. Virtualise rows (and columns if needed). Compute lens metrics with memoisation.
- **NEEDS DATA:** the house position per app (the existing grid already colours chips, so it probably exists).

### 5.3 Capability & Area Editor (`Editor.dc.html`)
Purpose: maintain the capability model (stages → domains → capabilities) and the business areas.

- **Tabs:** Capabilities (count) / Areas (count), as a segmented tab bar.
- **Unsaved-changes banner** (amber) appears after any edit, with Discard and Save capabilities / Save areas. These map to the existing "Save Capabilities" / "Save Areas" actions.
- **Capabilities tab: three panes.** This replaces the existing pop-ups.
  1. *Stage list* (left): badge, name, type pill (sequential / cross-cutting), capability count; "+ Add stage" (fields: ID e.g. 7 or E, Name, Type).
  2. *Stage content* (middle): header with badge, name, type, counts, Edit stage, + Add domain. Each domain is a card with Rename, + Capability and Delete icon buttons (with aria-labels). Capability rows: name, group tag, description; clicking a row selects it (accent left inset).
  3. *Inspector* (right): breadcrumb (stage › domain), **Edit capability**: Name (must be unique; validate inline), Group (optional), Description (textarea); Delete capability (danger text) and Apply.
- **Areas tab.**
  - *List:* filter input; "N without an owner" warning pill; + Add area. Columns: Area (children indented under parents, parents bold), Code (mono pill), Parent, Owner (avatar + name, or an amber "No owner" tag).
  - *Inspector, "Edit area":* breadcrumb, Area name, Alternate names (comma-separated), Parent area (select), Owner (people search), Delete area, Apply.
- Rename domain, add domain and add capability can use the same inspector pattern, or a small popover. Avoid full-screen pop-ups.
- Destructive actions need a confirmation.

### 5.4 App Detail (`AppDetail.dc.html`)
Purpose: everything about one application.

- **Header card.**
  - Breadcrumb (org hierarchy), name, APM ID as a copy-to-clipboard button ("Copied" feedback), state pills (operational status, strategic state), description.
  - Actions: Watch (toggle), Export, Edit profile (→ Profile Builder pre-selected with this app).
  - People strip (4 columns): role overline + avatar + name for Business owner, System architect, Product owner, RTB lead, CDR, Primary EA, Stack, ITSI.
  - Facts row: Service, Install type, Tier, Transaction cycle, LCT + service ID, Cease date.
- **Interface map.**
  - Radial layout: the subject app in the centre, confirmed systems on an inner ring (solid border, solid line), inferred "(possibly)" systems on an outer ring (dashed).
  - Filter: All / Confirmed / Inferred, with counts.
  - Clicking a node highlights it and its line and opens a **details panel** under the map: Interface, Protocol/port, Mode · confidence, Method; Direction select. For inferred links, **Confirm link** / **Reject link**.
  - Production suggestion: React Flow (or the existing graph library) so the map can be panned and zoomed.
- **Profile health card.** A score ring plus a checklist with fix links:
  - Ownership complete.
  - No capabilities mapped (→ Profile Builder).
  - N unresolved CMDB IDs (→ CMDB card).
  - Direction missing on N interfaces.
  - N inferred links awaiting confirmation.
  - Repositories inactive.

  Scoring: ok = 1, warn = 0.5, fail = 0, averaged. Ring green at 75 or above, amber 50–74, red below 50. **Put the rules in one config file.**
- **CMDB upstream card:** resolved items (green dot, name, APM ID) and unresolved items (amber).
- **Repositories card:** name link, workspace · org, Active / Inactive pill, MR count, last activity.
- **Discovered interfaces table:**
  - Search (interface, target, port) and All / Sync / Async filter.
  - Sortable Confidence column, with a bar that is green at 90% or above and amber below.
  - Columns: Mode pill, Method, and Direction (amber "Not set" when empty).
  - Clicking a row selects the matching node on the map.
- **NEEDS DATA:** interface direction (currently empty), confirmed vs inferred flag per link (the existing "(possibly)" prefix suggests it exists), and persistence for Watch and for Confirm/Reject.

### 5.5 Command Palette — new (`CommandPalette.dc.html`)
- Opens with ⌘K / Ctrl+K from anywhere, or by clicking the search box in the top bar. Modal over a dimmed page, max-width 700px, 88px from the top.
- **Input:** searches app names **and APM IDs**, capability names, area names and actions.
- **Scope chips:** All / Apps / Capabilities / Areas / Actions, with counts.
- **Results:**
  - Grouped by type, up to 5 per group in All (more in a single scope).
  - Each row has a type icon tile, the name with the matched substring highlighted, a sub-line (app: cycle/area; capability: "stage · domain"; area: owner), a state pill for apps, and the APM ID in mono.
- **Empty query:** shows Recent (last 3 opened) plus suggested actions.
- **Keyboard:** ↑/↓ move, Enter opens, Esc closes. Focus is trapped in the dialog and returns to the trigger on close. The listbox and options use proper ARIA (`role="listbox"`, `aria-selected`).
- **Actions:** Show coverage gaps / Show overlap hotspots (→ Grid with that lens), Map capabilities to apps (→ Profile Builder), Download all profiles as JSON, Add area, Add stage (→ Editor).
- Suggested: the `cmdk` library, if React. Search can run client-side over cached lists at this scale.

### 5.6 Compare & Rationalise — new (`Compare.dc.html`)
- Entry points: an overlap-hotspot cell in the Grid (add a "Compare" action to the cell), or the palette. URL carries the capability and area.
- **Left list:** the apps in that cell (checkbox, name, state pill). At most 3 selected; the others are disabled once 3 are picked.
- **Comparison grid:** an attribute column plus 3 app columns (each has an avatar tile, name linking to App Detail, APM ID, remove button; an empty slot shows "Pick an app on the left").
  - Rows: House position, APM ID, Capability · area, Other capabilities, Application owner, Interfaces, Repository activity.
  - "Highlight differences" toggle shades the rows where the values differ.
- **Decision row:** Keep / Consolidate / Retire per app (a radio group styled as a segmented control). Consolidate shows a "Consolidate into" select listing the other compared apps.
- **Decision summary bar (dark):** tally of keep / consolidate / retire, a Rationale textarea, Save decision, Export decision record.
- **NEEDS DATA:** a new `decisions` store (who, when, capability, area, app, decision, target, rationale). Saving should also update house position and write to an app history log. **Propose the schema before building.**

---

## 6. Behaviour that applies everywhere
- **Accessibility:** real `<button>` / `<a>` / `<input>` / `<label>` elements, never clickable divs. `aria-pressed` on toggle chips, `aria-expanded` on accordions, `aria-label` on icon-only buttons. Visible focus ring (accent, 2px offset). Text contrast at least 4.5:1.
- **States:** every list and table needs loading (skeleton), empty (friendly message plus the next action) and error states.
- **Feedback:** saves show a toast. Destructive actions confirm. Unsaved changes warn before navigating away.
- **Responsive:** must work from 1280px up. Below about 1000px, side panels stack under the main content and wide tables scroll horizontally inside their card, never the page.
- **URL state:** grid lens, view, density, visible columns, and palette/compare selections should live in the URL so a view can be shared ("Copy link to view").

---

## 7. Suggested libraries (check the repo first; ask before adding)
- Component primitives: shadcn/ui (Radix) or the repo's existing kit.
- Tables / grid virtualisation: TanStack Table + TanStack Virtual.
- Interface map: React Flow.
- Command palette: cmdk.
- Fonts: `@fontsource/ibm-plex-sans`, `@fontsource/ibm-plex-mono` (self-hosted, rather than Google Fonts, for an internal app).

---

## 8. Build order (stop for review after each phase)
1. **Foundation:** tokens, fonts, AppShell, the shared components in §3.
2. **App Detail** (layout, health card, table search/sort/select, map details panel).
3. **Portfolio Grid** (lenses, legend filter, header totals, sticky table, +N more, heatmap, density, virtualisation).
4. **Profile Builder** (stage accordion, per-capability override, sticky selected bar).
5. **Editor** (three-pane capabilities, areas inspector, unsaved-changes banner).
6. **Command Palette** (global shortcut, client-side index).
7. **Compare & Rationalise** (after the decisions schema is agreed).

**Definition of done for each screen:**
- Matches the design values.
- Uses real data only.
- Keyboard-operable.
- Loading, empty and error states handled.
- No console errors.
- Existing behaviour preserved (save, download, filters).
